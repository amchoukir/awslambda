
**To retrieve a list of ElasticTranscoder jobs with a status of Complete**

This example retrieves a list of ElasticTranscoder jobs with a status of Complete.

Command::

  aws elastictranscoder list-jobs-by-status --status Complete

Output::

 {
    "Jobs": []
 }
 	
