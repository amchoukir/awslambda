**To remove a member from a resource**

This example removes the specified member from a resource.

Command::

  aws workmail disassociate-delegate-from-resource --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 --resource-id r-68bf2d3b1c0244aab7264c24b9217443 --entity-id S-1-1-11-1111111111-2222222222-3333333333-3333

Output::

  None